#!/bin/sh

gsettings set org.gnome.desktop.background picture-uri "file:///var/ziabsWallpapers/1.jpg"

echo "\n----------------  Application Started  --------------"
echo "\n----------------  For Uninstall run this --------------"
echo "\n	     sudo /var/ziabsWallpapers/uninstall";
sleep 0.3;t=0.2;echo -n "\n ------------------- ";echo -n "T";sleep $t;echo -n "h";sleep $t;echo -n "a";sleep $t;echo -n "n";sleep $t;echo -n "k";sleep $t;echo -n "s";sleep $t;echo -n " ";sleep $t;echo -n ":";sleep $t;echo -n " ";sleep $t;echo -n "w";sleep $t;echo -n "w";sleep $t;echo -n "w";sleep $t;echo -n ".";sleep $t;echo -n "z";sleep $t;echo -n "i";sleep $t;echo -n "a";sleep $t;echo -n "b";sleep $t;echo -n "s";sleep $t;echo -n ".";sleep $t;echo -n "c";sleep $t;echo -n "o";sleep $t;echo -n "m ----------------\n \n";sleep 3;
